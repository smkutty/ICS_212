/***************************************************
 * NAME:    Sreelakshmi Kutty
 *
 * HOMEWORK:    1
 *
 * CLASS: ICS 212
 *
 * INSTRUCTOR:    Ravi Narayan
 *
 * DUE DATE:    28 JAN 2020
 *
 * FILE:    homework1.c
 *
 * DESCRIPTION: This file contains the driver and the
 *  user-intercation functionsfor Homework 1- the 
 *  measurement converseion program
 ***************************************************/

#include <stdio.h>

int main();
int user_interface();
double convert(double);
void print_table(int);

/***************************************************
 *
 * FUNCTION NAME: main
 *
 * DESCRIPTION: runs the functions user_input and
 * print_table
 *
 * PARAMETERS: none
 *
 * RETURN VALUES: none
 *
 ***************************************************/

int main()
{
    int max = user_interface();
    print_table(max);
    return 0;
}


/***************************************************
 *
 * FUNCTION NAME: user_interface
 *
 * DESCRIPTION: takes an integer and sends back the
 * same intger and a description about the program
 *
 * PARAMETERS: none
 *
 * RETURN VALUES: given number 
 *
 ***************************************************/

int user_interface()
{
    int num, result, t = 0;
    char dummy;

    printf("This program converts inches to centimeters.\nPlease enter maximum integers to show: ");
    scanf("%d", &num);

    
    while (t == 0)
    {
        if(num <= 0)
        {
            printf("Must be a positive integer: ");
            scanf("%d", &num);
        } else
        {
            result = num;
            t = 1;
        }
    }

    return result;
}

/***************************************************
 *
 * FUNCTION NAME: convert
 *
 * DESCRIPTION: takes value of inches and gives 
 * conversion into centimeteres
 *
 * PARAMETERS: inches (double) : number to convert 
 *
 * RETURN VALUES: val (double) : convereted number
 *
 ***************************************************/

double convert(double inches)
{
    double val = inches * 2.54;
    return val;
}

/***************************************************
 *
 * FUNCTION NAME: print_table
 *
 * DESCRIPTION: prints list of inches to centimeters,
 * starting from 0 inchest to the given number at
 * intervals of 0.5
 *
 * PARAMETERS: num (int) : max inches to convert
 *
 * RETURN VALUES: none
 *
 ***************************************************/ 

void print_table(int num)
{
    int c;
    double i = 0.00;
    printf("%10s%10s\n","inch", "cm");
    for(c = 0; c<= num * 2; c++)
    {
        printf("%10.2f%10.2f\n", i, convert(i));
        i= i + 0.5;
    }
}



