/*****************************************************************
 *
 * NAME: Sreelakshmi Kutty
 *
 * COURSE: ICS 212
 *
 * INSTRUCTOR: Ravi Narayan
 *
 * DUE DATE: 4 FEb 2020
 *
 * FILE: driver.c
 *
 * DESCRIPTION: This file contains the driver to test halfstring.c
 *
 *****************************************************************/


#include <stdio.h>
#include "halfstring.h"


/**************************************************************************
 *
 * Function: Main
 *
 * Description: Tests the halfstring function and provides three test cases
 *
 **************************************************************************/

int  main(int argc, char * argv[])
{
    char output[20], input[20], one[20] = "Sreelakshmi Kutty", two[20] = "", three[20] = "ics212 ^^ hw";

    printf("This program takes a string and prints its halved version \n such that it only includes every other character. \n Please enter a string: ");
    fgets(input, 20, stdin);
    printf("Your string,: %s", input);
    halfstring(input, output);

    /* THREE TEST CASES */
    
    printf("This is test case 1: %s\n", one);
    halfstring(one, output);

    printf("This is test case 2 (empty):  %s\n", two);
    halfstring(two, output);

    printf("This is test case 3: %s\n", three);
    halfstring(three, output);



return 0;
}






