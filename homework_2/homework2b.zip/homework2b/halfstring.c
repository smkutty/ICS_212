#include <stdio.h>
#include "halfstring.h"

/********************************************************************
 *
 * NAME: Sreelakshmi Kutty
 *
 * HOMEWORK: 2b
 *
 * COURSE: ICS 212
 *
 * INSTRUCTOR: Ravi Narayan
 *
 * DUE DATE: 4 Feb 2020
 *
 * FILE: halfstring.c
 *
 * DESCRIPTION: This file contains the driver function to create
 *              a new string that consists of the alternate string
 *
 *********************************************************************/

/**
 * Function: halfstring
 * 
 * Parameters: const char[], char[]
 *
 * Returns: none
 *
 * Description: takes a character array and prints a resulting array
 * 		with alternating characters
 *
 */
 
void halfstring(const char a[], char b[])
{

    int i, t, s;
    i = 0;
    t = 0;

    s = -1;
    while(a[i] != '\0')  /* getting string length */
    {
        s++;
        i++;
    }

    i = 0;
    while (i < s)
    {
        b[t] = a[i];
        i = i + 2;
        t++;
    }
    b[t] = '\0';
    printf("This is the halfstring version:  %s\n", b);
}



