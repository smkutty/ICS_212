/*********************************************************
 *
 * NAME: Sreelakshmi Kutty
 *
 * COURSE: ICS 212
 *
 * INSTRUCTOR: Ravi Narayan
 *
 * DUE DATE: 4 Feb 2020
 *
 * FILE: halstring.h
 *
 * DESCRIPTION: Header file containing halfstring prototype
 *
 *********************************************************/


void halfstring(const char[], char[]);

