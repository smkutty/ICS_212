/**********************************************************************
 *
 * Name: Sreelakshmi Kutty
 *
 * Course: ICS 212
 *
 * Instructor: Ravi Narayan
 *
 * Due date: 16 Feb 2020
 *
 * File: database.c
 *
 * Description: contains the 5 functions for account
 *
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "database.h"
#include "record.h"

extern int debugmode;

/***************************************
 * 
 * Function: addRecord
 *
 * Description: adds record to database
 *
 * Parameters: next (struct record **)
 * 	       acountno (int)
 * 	       name (char[])
 * 	       address (char[])
 * Return: 0
 *
 ***************************************/ 

int addRecord (struct record ** start, int uaccountno, char uname[], char uaddress[])
{
    struct record *new, *hold;
    int result;
    result = -1;
    hold = *start;

    /*  DEBUG FEATURE CODE START */
    if(debugmode == 1)
    {
        printf("\nDebug Mode On ********************** \n");
        printf("Function called: addRecord \n");
        printf("Parameters passed: \n");
        printf("Account number: %d\n", uaccountno);
        printf("Name: %s\n", uname);
        printf("Address: %s\n", uaddress);
        printf("************************************\n");
    }
    /*DEBUG FEAUTRE CODE END*/

    if(hold == NULL)
    {
        hold = (struct record*)malloc(sizeof(struct record));
        hold->accountno = uaccountno;
        strcpy(hold->name, uname);
        strcpy(hold->address, uaddress);
        *start = hold;
        result = 0;
    }
    else
    {
        while(hold->next != NULL)
        {
            hold = hold->next;
        }
        new = (struct record*)malloc(sizeof(struct record));
        new->accountno = uaccountno;
        strcpy(new->name, uname);
        strcpy(new->address, uaddress);

        new->next = NULL;
        hold->next = new;

        result = 0;
    }


    return result;
}

/***************************************
 * 
 * Function: printRecord
 *
 * Description: prints specified record
 *
 * Parameters: start (struct record * )
 * 	       accountno (int)
 *
 * Return: 0
 *
 ***************************************/ 

int printRecord (struct record * start, int uaccountno)
{
    struct record * current;
    int result;
    current = start;
    result = -1;

    /* DEBUG FEATURE CODE START*/
    if(debugmode == 1)
    {
        printf("\nDebug mode on ******************** \n");
        printf("Function called: printRecord \n");
        printf("Parameters passed:\n");
        printf("Account number: %d \n", uaccountno);
        printf("********************************** \n");
    }
     /* DEBUG DEATURE CODE END */

    while(current != NULL)
    {
        if(uaccountno == current->accountno)
        {
            printf("Account number: %d\n", current->accountno);
            printf("Name: %s\n", current->name);
            printf("Address: %s\n", current->address);
            printf("\n");

            result = 0;
        }
        current = current->next;
    }

    if(result == -1)
    {
        printf("No such record found \n");
    }

    return result;
}

/***************************************
 *
 * Function: printAllRecords
 *
 * Description: prints all records
 *
 * Parameters: start (struct record *)
 *
 * Return: void
 *
 ***************************************/

void printAllRecords (struct record * start)
{
    struct record * current;
    current = start;

    /*DEBUG FEATURE CODE START*/
    if(debugmode == 1)
    { 
        printf("\nDebug Mode On ********************\n");
        printf("Function called: printAllRecords \n");
        printf("No parameters passed \n");
        printf("**********************************\n");
    }
    /*DEBUG FEATURE CODE END*/
    
    if(current == NULL)
    {
        printf("No records to print. \n");
    }
    while(current != NULL)
    {
        printf("\n Printing all records ---------- \n");
        printf("Account number: %d\n", current->accountno);
        printf("Name: %s\n", current->name);
        printf("Address: %s\n", current->address);
        printf("\n");

        current = current->next;
    }
}

/****************************************
 *
 * Function: modifyRecord
 *
 * Description: modifies specified recor
 * 		with given addressd
 * 
 * Parameters: start (struct record *)
 * 	       accountno (int)
 * 	       address (char [])
 *
 * Return: 0
 *
 *****************************************/

int modifyRecord (struct record * start, int uaccountno, char uaddress[])
{
    struct record * current;
    int result;
    current = start;
    result = -1;

    /*DEBUG FEATURE CODE START*/
    if(debugmode == 1)
    {
        printf("\nDebug Mode On *********************** \n");
        printf("Function called: modifyRecord \n");
        printf("Parameters passed: \n");
        printf("Account number: %d \n", uaccountno);
        printf("Address: %s \n", uaddress);
        printf("*************************************\n");
    }
    /*DEBUG FEATURE CODE END*/

    while(current != NULL)
    {
        if(current->accountno == uaccountno)
        {
            strcpy(current->address, uaddress);
        }
        current = current->next;
    }

    return result;
}

/*****************************************
 *
 * Function: deleteRecord
 *
 * Description: deletes specified record
 *
 * Parameters: next (struct record **)
 * 	       accountno (int)
 *
 * Return: 0
 i*
 *****************************************/ 

int deleteRecord (struct record** start, int uaccountno)
{

    struct record * current, * previous;
    int result;

    current = * start;
    previous = * start;
    result = -1;

    /*DEBUG FEATURE CODE START*/
    if(debugmode == 1)
    {
        printf("\nDebug Mode On ***********************\n");
        printf("Function called: deleteRecord \n");
        printf("Parameters passed: \n");
        printf("Account number: %d\n", uaccountno);
        printf("*************************************\n");
    }
    /*DEBUG FEATURE CODE END*/

    while(current != NULL)
    {
        if((current->accountno) == uaccountno)
        {
            if(current == * start)
            {
                *start = current->next;
                free(current);
                current = * start;
                result = 0;
            }
            else
            {
                (previous->next) = (current->next);
                free(current);
                current = (previous->next);
                result = 0;
            }
        }
        else
        {
            previous = current;
            current = (current->next);
        }
    }
    return result;
}

/*********************************************
 *
 * Function: readfile
 *
 * Description: takes in a file and reads contents
 *              stores records in an array
 *
 * Parameters:
 *
 * Return: 0
 *
 *********************************************/
int readfile(struct record ** start, char filename[])
{
    char name[25], address[80], buffer;
    int temp, accountno, check, size, val, remain;

    FILE * fp = fopen(filename, "a");

    check = 0;

    if(fp == NULL)
    {
        val = 0;
    }

    while(check != 1)
    {
        if(fscanf(fp, "%d\n", &temp) != 1)
        {
            check = 1;
        }
        else
        {
            accountno = temp;
            fgets(name, 25, fp);

            for(size = 0; ((buffer = (fgetc(fp))) != '$') && (size < 80); size++)
            {
                address[size] = buffer;
            }
            val = 0;

            for ((remain = 79 - (size+1)); remain != 80; remain ++)
            {
                address[remain] = ' ';
            }

            addRecord(start, accountno, name, address);

        }
    }
    fclose(fp);
    return val;
}


/*******************************************
 *
 * Function: writefile
 *
 * Description: creates text file with records
 *
 * Parameters: 
 *
 * Return: 0
 *
 *******************************************/
int writefile(struct record * start, char filename[])
{
    FILE * ofp;
    int val;
    struct record * hold;

    hold = start;
    ofp = fopen(filename, "w");

    if(ofp == NULL)
    {
        val = 1;
    }
    else
    {
        while(hold != NULL)
        {
            fprintf(ofp, "%d\n", hold->accountno);
            fprintf(ofp, "%s\n", hold->name);
            fprintf(ofp, "%s\n", hold->address);
            fprintf(ofp, "\n\n");

            hold = hold->next; 
        }

        fclose(ofp);
        val = 0;
    }
    

    return val;
}

/*********************************************
 *
 * Function: cleanup
 *
 * Description: releases all space used
 *
 * Parameters:
 *
 * Return:
 *
 *********************************************/

void cleanup(struct record ** start)
{
    struct record * current;
    current = * start;

    while(current != NULL)
    {
        free(current);
        current = current->next;
    }
}






